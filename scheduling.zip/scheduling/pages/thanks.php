<!DOCTYPE html>
<html lang="en">
<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title>Aerobatic Form Submit Demo</title>
  <meta name="description" content="This demo shows how to use the Aerobatic form-submit plugin">
  <meta name="author" content="Aerobatic">

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- FONT
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link href='//fonts.googleapis.com/css?family=Raleway:400,300,600' rel='stylesheet' type='text/css'>

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="stylesheet" href="/css/normalize.css">
  <link rel="stylesheet" href="/css/skeleton.css">
  <link rel="stylesheet" href="/css/custom.css">
</head>
<body class="code-snippets-visible">
  <div class="navbar-spacer"></div>
  <nav class="navbar">
    <div class="container">
      <a href="https://www.aerobatic.com"><img src="https://www.aerobatic.com/media/aerobatic-header-logo.png"></a>
    </div>
  </nav>

  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <div class="container">
    <section class="header">
      <h1 class="title">Form Submit Demo</h1>
    </section>

    <!-- Example -->
    <div class="docs-section examples" id="examples">
      <div class="row example">
        <h4>Thank you for your interest. Someone will be in touch with you soon</h4>
        <p>
          <a class="button button-primary" href="/" role="button">Back</a>
        </p>
      </div>
    </div>
  </div>
</body>
</html>